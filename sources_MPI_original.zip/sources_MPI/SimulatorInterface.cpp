#include "NeuronNetwork.h"
#include "SimulatorInterface.h"

#include <chrono> // #include <boost/chrono.hpp>

using namespace std;

SimulatorInterface::SimulatorInterface(){
	// define default output data file format
	output_suffix = ".ygout"; // filename extension
	delim = ',';
	indicator = '>';
}

bool SimulatorInterface::import(string in_filename_input){
	// read main input file
	in_filename = in_filename_input;
	ifstream inputfile(in_filename);
	if (inputfile){
		cout << "------------------------------------------------------------" << endl;
		cout << "Importing " << in_filename << "..." << endl;
	}
	else {
		cout << "Error: cannot open file" << in_filename << endl;
		return 0;
	}
	
	// claim variables to be assigned
	int Num_pop;
	double dt;
	int step_tot;
	vector<int> N_array;
	// temporary data storage
	vector<string> pop_para; // parameters of neuron popluation
	string syn_para; // parameters of synapses
	vector< vector<double> > ext_spike_settings; // (int pop_ind, int type_ext, double K_ext, int Num_ext, double rate_ext)
	vector< vector<double> > rate_ext_t; // vector<duoble> rate_ext(t)
	vector< vector<double> > ext_current_settings; // (int pop_ind, double mean, double std)
	vector< vector<double> > init_condition_settings; // (int pop_ind, double p_fire)
	vector<int> sampling_pop_ind; //
	vector< vector<int> > sampling_sample_ind; //
	vector<double> runaway_killer_setting; // [runaway_steps, runaway_mean_num_ref]
	vector< vector<bool> > pop_potential_sampling_index; // the length of time vector
	vector<int> pop_potential_sampling_pop_ind;

	// read data
	string line_str, entry_str; // temporary container for the entire while loop
	double data_type = -1; // decided by data-info line
	size_t found;
	while (getline(inputfile, line_str)){
		istringstream line_ss(line_str); // local variable: lifetime is only a signle loop (scope is within "{}")! reusing it by ".str()" may cause fatal error because the internal error flag remains the same. Everytime using "while(getline(...)){}" will change internal error flag!
		if (line_str.empty()){continue;}
		else if (line_str.front() == indicator){// read data-info line
			data_type = -1; // be careful! this line is important
			// read number of populations
			found = line_str.find("number of populations");
			if (found != string::npos){// if found match
				data_type = 0; // decided by data-info line!!!
				cout << "\t Reading number of populations..." << endl;
				continue; // move to next line
			}
			// read time step (ms)
			found = line_str.find("time step");
			if (found != string::npos){// if found match
				data_type = 1;
				cout << "\t Reading time step..." << endl;
				continue; // move to next line
			}
			// read total steps
			found = line_str.find("total steps");
			if (found != string::npos){// if found match
				data_type = 2;
				cout << "\t Reading total steps..." << endl;
				continue; // move to next line
			}

			// read vector N_array
			found = line_str.find("number of neurons");
			if (found != string::npos){// if found match
				data_type = 4; // decided by data-info line!!!
				cout << "\t Reading number of neurons in each population..." << endl;
				continue; // move to next line
			}
			
			// read external spike setting
			found = line_str.find("external spikes");
			if (found != string::npos){// if found match
				data_type = 5; // decided by data-info line!!!
				cout << "\t Reading external spike settings..." << endl;
				continue; // move to next line
			}

			// read external current setting
			found = line_str.find("external current");
			if (found != string::npos){// if found match
				data_type = 6; // decided by data-info line!!!
				cout << "\t Reading external current settings..." << endl;
				continue; // move to next line
			}

			// read random initial condition
			found = line_str.find("random initial condition");
			if (found != string::npos){// if found match
				data_type = 7; // decided by data-info line!!!
				cout << "\t Reading random initial condition settings..." << endl;
				continue; // move to next line
			}

			// read membrane potential and currents sampling setting
			found = line_str.find("membrane potential and currents sampling");
			if (found != string::npos){// if found match
				data_type = 8; // decided by data-info line!!!
				cout << "\t Reading membrane potential and currents data sampling settings..." << endl;
				continue; // move to next line
			}
			
			// read neuron population parameter setting
			found = line_str.find("neuron population parameter setting");
			if (found != string::npos){// if found match
				data_type = 9; // decided by data-info line!!!
				cout << "\t Reading neuron population parameter settings..." << endl;
				continue; // move to next line
			}

			// read synapse parameter setting
			found = line_str.find("synapse parameter setting");
			if (found != string::npos){// if found match
				data_type = 12; // decided by data-info line!!!
				cout << "\t Reading synapse parameter settings..." << endl;
				continue; // move to next line
			}

			// read runaway killer setting
			found = line_str.find("runaway killer setting");
			if (found != string::npos){
				data_type = 10;
				cout << "\t Reading runaway killer setting..." << endl;
				continue;
			}

			// read population membrane potential sampling
			found = line_str.find("population potential sampling");
			if (found != string::npos){
				data_type = 11;
				cout << "\t Reading population potential sampling setting..." << endl;
				continue;
			}

		}//read data-info line	

		else{// read according data
			// read number of populations
			if (data_type == 0){
				getline(line_ss, entry_str, delim); // get first entry
				stringstream(entry_str) >> Num_pop;// from string to numerical value
				pop_para.resize(Num_pop);
				continue;
			}
			// read time_step
			else if(data_type == 1){
				getline(line_ss, entry_str, delim); // get first entry
				stringstream(entry_str) >> dt;// from string to numerical value
				continue;
			}
			// read step_tot
			else if (data_type == 2){
				getline(line_ss, entry_str, delim); // get first entry
				stringstream(entry_str) >> step_tot;// from string to numerical value
				continue;
			}
				
			// read N
			else if (data_type == 4){
				while (getline(line_ss, entry_str, delim)){
					N_array.resize(N_array.size()+1);
					stringstream(entry_str) >> N_array.back();
				}
				continue;
			}

			// external spike setting (int pop_ind, int type_ext, double K_ext, int Num_ext, double rate_ext)
			else if (data_type == 5){
				ext_spike_settings.resize(ext_spike_settings.size()+1);
				rate_ext_t.resize(rate_ext_t.size()+1);
				double pop_ind;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> pop_ind;
				ext_spike_settings.back().push_back(pop_ind);
				double type_ext;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> type_ext;
				ext_spike_settings.back().push_back(type_ext);
				double K_ext;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> K_ext;
				ext_spike_settings.back().push_back(K_ext);
				double Num_ext;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> Num_ext;
				ext_spike_settings.back().push_back(Num_ext);
				double rate_ext_temp;
				getline(inputfile, line_str);// read next line
				istringstream line_ss_rate(line_str);
				while (getline(line_ss_rate, entry_str, delim)){
					stringstream(entry_str) >> rate_ext_temp;
					rate_ext_t.back().push_back(rate_ext_temp);
				}
				continue;
			}

			// external current setting (int pop_ind, double mean, double std)
			else if (data_type == 6){
				ext_current_settings.resize(ext_current_settings.size()+1);
				double pop_ind;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> pop_ind;
				ext_current_settings.back().push_back(pop_ind);
				double mean;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> mean;
				ext_current_settings.back().push_back(mean);
				double std;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> std;
				ext_current_settings.back().push_back(std);
				continue;
			}

			// random initial condition setting (int pop_ind, double p_fire)
			else if (data_type == 7){
				init_condition_settings.resize(init_condition_settings.size()+1);
				double pop_ind;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> pop_ind;
				init_condition_settings.back().push_back(pop_ind);
				double p_fire;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> p_fire;
				init_condition_settings.back().push_back(p_fire);
				continue;
			}

			// membrane potential and currents data sampling setting (int pop_ind, vector<int> sample_ind)
			else if (data_type == 8){
				// pop_ind
				int pop_ind;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> pop_ind;
				sampling_pop_ind.push_back(pop_ind);
				// sample_ind
				sampling_sample_ind.resize(sampling_sample_ind.size()+1);
				int entry_int;
				getline(inputfile, line_str);// read next line
				istringstream line_ss_sample_ind(line_str);
				while (getline(line_ss_sample_ind, entry_str, delim)){
					stringstream(entry_str) >> entry_int;
					sampling_sample_ind.back().push_back(entry_int);
				}
				continue;
			}
			
			// neuron population parameter setting
			else if (data_type == 9){
				// pop_ind and number of parameters
				int pop_ind, num_para;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> pop_ind;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> num_para;
				// store parameter settings
				stringstream pop_para_ss;
				for (int c = 0; c < num_para; ++c){
					getline(inputfile, line_str); // read next line
					pop_para_ss << line_str; // store in pop_para
				}
				pop_para[pop_ind] = pop_para_ss.str();
				continue;
			}

			// synapse parameter setting
			else if (data_type == 12){
				// number of parameters
				int num_para;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> num_para;
				// store parameter settings
				stringstream syn_para_ss;
				for (int c = 0; c < num_para; ++c){
					getline(inputfile, line_str); // read next line
					syn_para_ss << line_str; // store in pop_para
				}
				syn_para = syn_para_ss.str();
				continue;
			}

			// read runaway killer setting
			else if (data_type == 10){
				double steps, mean_num_ref;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> steps;
				runaway_killer_setting.push_back(steps);
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> mean_num_ref;
				runaway_killer_setting.push_back(mean_num_ref);
				continue;
			}

			// read population potential sampling setting
			else if (data_type == 11){
				int pop_ind;
				bool sample_time_index;
				getline(line_ss, entry_str, delim);
				stringstream(entry_str) >> pop_ind;
				pop_potential_sampling_pop_ind.push_back(pop_ind);
				getline(inputfile, line_str);// read next line
				istringstream line_ss_bool(line_str);
				pop_potential_sampling_index.resize(pop_potential_sampling_index.size()+1);
				while (getline(line_ss_bool, entry_str, delim)){
					stringstream(entry_str) >> sample_time_index;
					pop_potential_sampling_index.back().push_back(sample_time_index);
				}
				continue;
			}

		}// read according data
	} // while



	











	// read synapse definition input file
	string syn_filename = in_filename;
	syn_filename.append("_syn"); // .ygin_syn

	ifstream syn_file(syn_filename);
	if (syn_file){}
	else {
		cout << "Error: cannot open file" << in_filename << endl;
		return 0;
	}
	
	// temporary data storage
	vector< vector<int> > I_temp, J_temp; //for chemical synapses
	vector< vector<double> > K_temp, D_temp; //for chemical synapses
	vector< vector<int> > IJKD_chem_info; // {Type(0:AMPA/1:GABAa/2:NMDA),Pre_pop_ind(0/1/...),Post_pop_ind(0/1/...)}
	
	// read data
	data_type = -1; // decided by data-info line
	while (getline(syn_file, line_str)){
		istringstream line_ss(line_str); // local variable: lifetime is only a signle loop (scope is within "{}")! reusing it by ".str()" may cause fatal error because the internal error flag remains the same. Everytime using "while(getline(...)){}" will change internal error flag!
		if (line_str.empty()){continue;}
		else if (line_str.front() == indicator){// read data-info line
			data_type = -1; // be careful! this line is important
			// read connection data: [I;J;K;D] (chemical)
			found = line_str.find("chemical connection");
			if (found != string::npos){// if found match
				data_type = 3; 
				cout << "\t Reading chemical connection..." << endl;
				continue; // move to next line
			}
		}//read data-info line	

		else{// read according data
			// read I_temp, J_temp, K_temp, D_temp
			if (data_type == 3){
				// type, pre_pop_ind, post_pop_ind,
				IJKD_chem_info.resize(IJKD_chem_info.size()+1);
				// type
				getline(line_ss, entry_str, delim);
				int type_temp;
				stringstream(entry_str) >> type_temp;
				IJKD_chem_info.back().push_back(type_temp);
				// pre_pop_ind
				getline(line_ss, entry_str, delim);
				int pre_pop_ind;
				stringstream(entry_str) >> pre_pop_ind;
				IJKD_chem_info.back().push_back(pre_pop_ind);
				// post_pop_ind
				getline(line_ss, entry_str, delim);
				int post_pop_ind;
				stringstream(entry_str) >> post_pop_ind;
				IJKD_chem_info.back().push_back(post_pop_ind);

				int entry_int;
				double entry_double;
				// I_temp
				getline(syn_file, line_str);// read next line
				istringstream line_ss_I(line_str);
				I_temp.resize(I_temp.size()+1);
				while (getline(line_ss_I, entry_str, delim)){
					stringstream(entry_str) >> entry_int;
					I_temp.back().push_back(entry_int);
				}
				// J_temp
				getline(syn_file, line_str);// read next line
				istringstream line_ss_J(line_str);
				J_temp.resize(J_temp.size()+1);
				while (getline(line_ss_J, entry_str, delim)){
					stringstream(entry_str) >> entry_int;
					J_temp.back().push_back(entry_int);
				}
				// K_temp
				getline(syn_file, line_str);// read next line
				istringstream line_ss_K(line_str);
				K_temp.resize(K_temp.size()+1);
				while (getline(line_ss_K, entry_str, delim)){
					stringstream(entry_str) >> entry_double;
					K_temp.back().push_back(entry_double);
				}
				// D_temp
				getline(syn_file, line_str);// read next line
				istringstream line_ss_D(line_str);
				D_temp.resize(D_temp.size()+1);
				while (getline(line_ss_D, entry_str, delim)){
					stringstream(entry_str) >> entry_double;
					D_temp.back().push_back(entry_double);
				}
				continue;
			}

		}// read according data
	} // while









	// build NeuronNetwork based on data imported
	network = NeuronNetwork(N_array, dt, step_tot);
	cout << "\t Network created." << endl;
	cout << "\t Initialising neuron populations...";
	for (unsigned int ind = 0; ind < N_array.size(); ++ind){
		network.NeuronPopArray.push_back(Neurons(ind, N_array[ind], network.dt, network.step_tot));
		network.NeuronPopArray.back().set_para(pop_para[ind], delim);
		cout << ind+1 << "...";
	}
	cout << "done." << endl;

	// chemical connections
	if (I_temp.size() != 0){
		cout << "\t Initialising chemical synapses... ";
		for (unsigned int ind = 0; ind < I_temp.size(); ++ind){
			int type = IJKD_chem_info[ind][0];
			int i_pre = IJKD_chem_info[ind][1];
			int j_post = IJKD_chem_info[ind][2];
			network.ChemicalSynapsesArray.push_back(ChemicalSynapses(network.dt, network.step_tot));
			network.ChemicalSynapsesArray.back().init(type, i_pre, j_post, network.N_array[i_pre], network.N_array[j_post], I_temp[ind], J_temp[ind], K_temp[ind], D_temp[ind]);
			network.ChemicalSynapsesArray.back().set_para(syn_para, delim);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// external spike setting (int pop_ind, int type_ext, double K_ext, int Num_ext)
	// vector<double> rate_ext_t
	if (ext_spike_settings.size() != 0){
		cout << "\t External spike settings...";
		for (unsigned int ind = 0; ind < ext_spike_settings.size(); ++ind){
			int j_post = int(ext_spike_settings[ind][0]);
			int type_ext = int(ext_spike_settings[ind][1]);
			double K_ext = ext_spike_settings[ind][2];
			int Num_ext = int(ext_spike_settings[ind][3]);
			network.ChemicalSynapsesArray.push_back(ChemicalSynapses(network.dt, network.step_tot));
			network.ChemicalSynapsesArray.back().init(type_ext, j_post, network.N_array[j_post], K_ext, Num_ext, rate_ext_t[ind]);
			network.ChemicalSynapsesArray.back().set_para(syn_para, delim);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// external current setting (int pop_ind, double mean, double std)
	if (ext_current_settings.size() != 0){
		cout << "\t External current settings...";
		for (unsigned int ind = 0; ind < ext_current_settings.size(); ++ind){
			int pop_ind = int(ext_current_settings[ind][0]);
			double mean = ext_current_settings[ind][1];
			double std = ext_current_settings[ind][2];
			network.NeuronPopArray[pop_ind].set_gaussian_I_ext(mean, std);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// random initial condition settings (int pop_ind, double p_fire)
	if (init_condition_settings.size() != 0){
		cout << "\t Random initial condition settings...";
		for (unsigned int ind = 0; ind < init_condition_settings.size(); ++ind){
			int pop_ind = int(init_condition_settings[ind][0]);
			double p_fire = init_condition_settings[ind][1];
			network.NeuronPopArray[pop_ind].random_V(p_fire);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}
	
	// membrane potential and currents data sampling settings(int pop_ind, vector<int> sample_ind)
	if (sampling_pop_ind.size() != 0){
		cout << "\t Membrane potential and currents data sampling settings...";
		for (unsigned int ind = 0; ind < sampling_pop_ind.size(); ++ind){
			int pop_ind = sampling_pop_ind[ind];
			network.NeuronPopArray[pop_ind].add_VI_sampling(sampling_sample_ind[ind]);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}	
	
	// population membrane potential sampling
	if (pop_potential_sampling_pop_ind.size() != 0){
		cout << "\t Population membrane potential sampling settings...";
		for (unsigned int ind = 0; ind < pop_potential_sampling_pop_ind.size(); ++ind){
			int pop_ind = pop_potential_sampling_pop_ind[ind];
			network.NeuronPopArray[pop_ind].add_pop_V_sampling(pop_potential_sampling_index[ind]);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// initialise runaway-killer
	if (runaway_killer_setting.size() != 0){
		for (int ind = 0; ind < network.Num_pop; ++ind){
			network.NeuronPopArray[ind].init_runaway_killer(int(runaway_killer_setting[0]), runaway_killer_setting[1]);
		}
		cout << "\t Runaway killer licensed." << endl;
		cout << "\t \t No women, no kids." << endl;
	}


	cout << "Importing done." << endl;
	return 1;
}

void SimulatorInterface::simulate(){
	// simulate
	for (int i = 0; i < network.step_tot; ++i){
		network.update(i);
	}
	cout << "Simulation done." << endl;
}

void SimulatorInterface::output_results(){

	// creat output file name using some pre-defined format
	string filename; // string which will contain the result
	ostringstream convert_temp;   // stream used for the conversion
	// Make use of the input file path and name
	string in_filename_trim;
	istringstream in_filename_ss(in_filename);
	getline(in_filename_ss, in_filename_trim, '.');
	// Using time since epoch to stamp the output file
	chrono::high_resolution_clock::duration tse = chrono::high_resolution_clock::now().time_since_epoch();
	chrono::milliseconds tse_ms = chrono::duration_cast<chrono::milliseconds>(tse);
	unsigned long long time_stamp = tse_ms.count(); // ms from epoch, better than "time_t time_stamp = time(0);"
	// Combine all the parts of the output file path and name
	convert_temp << in_filename_trim << "_" << time_stamp  << output_suffix; // insert the textual representation of 'Number' in the characters in the stream
	filename = convert_temp.str(); // set 'Result' to the contents of the stream
	// creat output file
	output_file.open(filename);
	
	
	// write data
	cout << "Outputting results into file..." << endl;
	// dump step_killed
	output_file << indicator << " step_killed" << delim << network.step_killed << delim << "#var name, var value" << endl;
	// dump population data
	for (int i = 0; i < network.Num_pop; i++){
		network.NeuronPopArray[i].output_results(output_file, delim, indicator);
	}
	// dump synapse data
	for (unsigned int i = 0; i < network.ChemicalSynapsesArray.size(); i++){
		network.ChemicalSynapsesArray[i].output_results(output_file, delim, indicator);
	}

	cout << "Outputting done." << endl << "------------------------------------------------------------" << endl;
	// Write data file name to stdout and use "grep ygout" to extract it!
	cout << "Data file name is: " << endl;
	cout << filename << endl;	
}












