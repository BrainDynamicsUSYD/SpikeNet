#include <stdlib.h>
#include <iomanip>
#include <random> //<boost/random.hpp>
#include <cmath>
#include <algorithm>
#include <stdio.h> // for printf
#include <time.h>       /* time */

#include <fstream> // fstream : Stream class to both read and write from / to files
#include <sstream>  // stringstream is input and output


#include "Neurons.h"
// no need to include what have been included in the header file

Neurons::Neurons(int pop_ind_input, int N_input, double dt_input, int step_tot_input){

	pop_ind = pop_ind_input;
	N = N_input;
	dt = dt_input;
	step_tot = step_tot_input;
	
	// Using consistant units: msec+mV+nF+miuS+nA
	// Initialise default parameters
	// Model of <<The Asynchronous State in Cortical Circuits>>
	Cm = 0.25; // nF
	tau_ref = 2.0; // absolute refractory time (ms), 3.0
	// Potential constants (mV)
	V_rt = -60.0;   // Reset, usually same as leak reversal, use -75.0 to model relative refractory period??
	V_lk = -70.0;   // Leak reversal, -70.0
	V_th = -50.0;   // Threshold // -55.0
	// Leak conductance
	g_lk = 0.0167;   // (uS=miuSiemens), time constants=Cm/gL=15 ms!

	// Initialise defualt parameters
	init();
}




void Neurons::init(){
	
	// I_ext
	I_ext_mean = 0.0;
	I_ext_std = 0.0;


	// Initialise arrarys storing instantaneous neuron states
	V.assign(N, V_lk); // All zeros	
	I_leak.assign(N, 0.0);
	I_AMPA.assign(N, 0.0);
	I_GABA.assign(N, 0.0);
	I_NMDA.assign(N, 0.0);
	I_GJ.assign(N, 0.0);
	I_ext.assign(N, 0.0);
	ref_step_left.assign(N, 0);
	ref_steps = (int)round(tau_ref / dt);
	num_spikes_pop.assign(step_tot, 0);
	spike_hist_tot.reserve(step_tot*50); // reserve!
	num_ref_pop.assign(step_tot, 0);

	// Random seed (random engine should be feed with DIFFERENT seed at every implementation)
	random_device rd; // random number from operating system for seed
	my_seed = rd(); // record seed
	//my_seed = 321;
	//cout << "My_seed is: " << my_seed << endl;

	// Runaway killer is initially a sleeper agent
	killer_license = false;
	runaway_killed = false;
	step_killed = -1;
}



void Neurons::set_para(string para_str, char delim){
	if (!para_str.empty()){
		istringstream para(para_str);
		string para_name, para_value_str, line_str; 
		double para_value;
		while (getline(para, line_str)){
			istringstream line_ss(line_str);
			getline(line_ss, para_name, delim); // get parameter name
			getline(line_ss, para_value_str, delim); // get parameter value (assume double)
			stringstream(para_value_str) >> para_value; // from string to numerical value
			if (para_name.find("Cm") != string::npos){Cm = para_value;}
			else if (para_name.find("tau_ref") != string::npos){tau_ref = para_value;}
			else if (para_name.find("V_rt") != string::npos){V_rt = para_value;}
			else if (para_name.find("V_lk") != string::npos){V_lk = para_value;}
			else if (para_name.find("V_th") != string::npos){V_th = para_value;}
			else if (para_name.find("g_lk") != string::npos){g_lk = para_value;}
		}
	}
	// re-initialise population!
	init();
}


string Neurons::dump_para(char delim){
	stringstream dump;
	dump << "Cm" << delim << Cm << delim << endl;
	dump << "tau_ref" << delim << tau_ref << delim << endl;
	dump << "V_rt" << delim << V_rt << delim << endl;
	dump << "V_lk" << delim << V_lk << delim << endl;
	dump << "V_th" << delim << V_th << delim << endl;
	dump << "g_lk" << delim << g_lk << delim << endl;
	dump << "seed" << delim << my_seed << delim << endl;
	return dump.str();
}



void Neurons::random_V(double p){
	// Generate random initial condition for V.
	// Generate uniform random distribution
	gen.seed(my_seed);// reseed random engine!
	uniform_real_distribution<double> uniform_dis(0.0, 1.0);//boost::binomial_distribution<int> binml_spike(2,3.0);
	auto ZeroOne = bind(uniform_dis,gen);

	// cout << "RAND_MAX = " << RAND_MAX << endl; // 
	for (int i = 0; i < N; ++i) {
		// Generate random number.
		//ZeroOne = uniform_dis(gen); // range is [0,1]
		V[i] = V_rt + (V_th - V_rt) / (1.0 - p)*ZeroOne();
	}
}



void Neurons::update_spikes(int step_current){
	// Reset currents to be zeros, because they need to be re-calculated at every step
	// no need to reset I_leak
	fill(I_AMPA.begin(), I_AMPA.end(), 0);
	fill(I_GABA.begin(), I_GABA.end(), 0);
	fill(I_NMDA.begin(), I_NMDA.end(), 0);
	fill(I_GJ.begin(), I_GJ.end(), 0);
	fill(I_ext.begin(), I_ext.end(), 0);// fast way to do it, dump in 16 bytes at a time until it gets close to the end

	// Find the firing neurons, record them, reset their potential and set them to be refractory
	spikes_current.clear(); // empty vector
	int spike_counter = 0;
	for (int i = 0; i < N; ++i){
		if (ref_step_left[i] == 0 && V[i] >= V_th){
			spikes_current.push_back(i); // record firing neurons
			V[i] = V_rt; // reset potential
			ref_step_left[i] = ref_steps; // steps left for being refractory
			spike_counter += 1;
		}
	}
	// record number of spikes
	num_spikes_pop[step_current] = spike_counter; 

	// Collect total spike history data
	if (spike_counter > 0){
		// .end(): ONE ELEMENT PAST to the last location
		// see http://www.cs.northwestern.edu/~riesbeck/programming/c++/stl-iterators.html
		copy(spikes_current.begin(), spikes_current.end(), back_inserter(spike_hist_tot));
	}


	// Refraction count-down and record number of refractory neurons
	int num_ref_temp = 0;
	for (int i = 0; i < N; ++i){
		if (ref_step_left[i] > 0){
			ref_step_left[i] -= 1;
			num_ref_temp += 1;
		}
	}
	num_ref_pop[step_current] = num_ref_temp;

		
	// runaway check
	runaway_check(step_current);
	
}


void Neurons::update_V(int step_current){
	// This function updates menbrane potentials for non-refractory neurons

	// Gaussian white external currents
	if (I_ext_mean != 0.0){
		if (I_ext_std != 0.0){
			// Gaussian random generator
			gen.seed(my_seed+step_current);// reseed random engine!
			normal_distribution<double> nrm_dist(I_ext_mean, I_ext_std);
			auto gaus = bind(nrm_dist,gen);
			// Generate Gaussian white noise. White means not temporally correlated	
			for (int i = 0; i < N; ++i) { I_ext[i] = gaus(); }				
		}
		else { for (int i = 0; i < N; ++i) { I_ext[i] = I_ext_mean;} }
 	}


	// Collect Currents from all pre-synapses!!!!!!!!!!!!!!!


	// update menbrane potentials
	double Vdot;
	for (int i = 0; i < N; ++i){
		if (ref_step_left[i] == 0){ // Only update the non-refractory neurons
			// leaky current
			I_leak[i] = -g_lk * (V[i] - V_lk); 
			// using simple Euler method
			Vdot = (I_leak[i] + I_AMPA[i] + I_GABA[i] + I_NMDA[i] + I_GJ[i] + I_ext[i])/Cm;
			V[i] += Vdot * dt;
			// Note that delta-function coupling is very different from the above conductance-based model!
		}
	}

}




void Neurons::add_VI_sampling(vector<int> VI_sample_ind_input){
	VI_sample_ind = VI_sample_ind_input;
	int sample_size = VI_sample_ind.size();
	// initialise V_sample
	V_sample.resize(sample_size); for (int i = 0; i < sample_size; ++i){ V_sample[i].resize(step_tot); }
	// initialise I_sample
	int current_type_tot = 6; // 6 different membrane current types
	I_sample.resize(current_type_tot); 
	for (int c = 0; c < current_type_tot; ++c){
		I_sample[c].resize(sample_size);
		for (int i = 0; i < sample_size; ++i){ I_sample[c][i].resize(step_tot); }
	}
	
}

void Neurons::add_pop_V_sampling(vector<bool> pop_V_sample_ind_input){
	pop_V_sample_ind = pop_V_sample_ind_input;
	// memory management
	// count non zero elements
	int count = 0;
	for (unsigned int i = 0; i < pop_V_sample_ind.size(); ++i){
		if (pop_V_sample_ind[i]){
			count += 1;
		}
	}
	pop_V_sample.reserve(count*N); // "reserve" sets the capacity of the container vector
}


void Neurons::sample_data(int step_current){
	if (!VI_sample_ind.empty()){
		for (unsigned int i = 0; i < VI_sample_ind.size(); ++i){
			int ind_temp = VI_sample_ind[i];
			V_sample[i][step_current] = V[ind_temp];
			I_sample[0][i][step_current] = I_leak[ind_temp];
			I_sample[1][i][step_current] = I_AMPA[ind_temp];
			I_sample[2][i][step_current] = I_GABA[ind_temp];
			I_sample[3][i][step_current] = I_NMDA[ind_temp];
			I_sample[4][i][step_current] = I_GJ[ind_temp];
			I_sample[5][i][step_current] = I_ext[ind_temp];
		}
	}

	if (!pop_V_sample_ind.empty()){
		if (pop_V_sample_ind[step_current]){
			pop_V_sample.push_back(V);
		}
	}
}



void Neurons::set_gaussian_I_ext(double mean, double std){
	I_ext_mean = mean;
	I_ext_std = std;
}



void Neurons::init_runaway_killer(int steps, double mean_num_ref){
	min_pop_size = 100;
	if (N > min_pop_size){
		killer_license = true;
		runaway_steps = steps;
		runaway_mean_num_ref = mean_num_ref;
	}
}



void Neurons::runaway_check(int step_current){
	if (killer_license == true && runaway_killed == false && step_current > runaway_steps){
		// find mean value of num_ref over the last runaway_steps
		vector<int>::const_iterator first, last;
		// first element to be accumulated
		first = num_ref_pop.begin() + (step_current - runaway_steps + 1); 
		// one element pass the last element to be accumulated
		last = num_ref_pop.begin() + (step_current + 1); 
		double mean_num_ref = accumulate(first, last, 0.0) / double(runaway_steps);
		//be careful!! accumulate range is : [first,last)
		if (mean_num_ref >= runaway_mean_num_ref*N){
			runaway_killed = true;
			step_killed = step_current;
			cout << "warning: runaway killed at " << step_current*dt << " (ms)..."<< flush;
		}
	}
}



void Neurons::output_results(ofstream& output_file, char delim, char indicator){

	// spike_hist_tot
	output_file << indicator << " spike_hist_tot" << delim << pop_ind << delim << "#var name, pop index" << endl;
	write2file(output_file, delim, spike_hist_tot);

	// num_spikes_pop
	output_file << indicator << " num_spikes_pop" << delim << pop_ind << delim << "#var name, pop index" << endl;
	write2file(output_file, delim, num_spikes_pop);


	// num_ref_pop
	output_file << indicator << " num_ref_pop" << delim << pop_ind << delim << "#var name, pop index" << endl;
	write2file(output_file, delim, num_ref_pop);


	// VI_sample
	if (!VI_sample_ind.empty()){
		output_file << indicator << " VI_sample" << delim << pop_ind << delim << "#var name, pop index" <<  endl;
		output_file << VI_sample_ind.size() << delim << "#sample size, following data: sample index vector; V_sample(matrix); I_leak(matrix); I_AMAP; I_GABA; I_NMDA; I_GJ; I_ext;"<< endl;
		// VI_sample_ind
		write2file(output_file, delim, VI_sample_ind);
		// VI_sample
		write2file(output_file, delim, V_sample); // V_sample is a 2D matrix
		int currents_type_tot = 6; // 6 different membrane current types
		for (int c = 0; c < currents_type_tot; ++c){
			write2file(output_file, delim, I_sample[c]); // I_sample[.] is a 2D matrix
		}
	}
		
	// pop_V_sample
	if (!pop_V_sample_ind.empty()){
		output_file << indicator << " pop_V_sample" << delim << pop_ind << delim << "#var name, pop index" <<  endl;
		output_file << pop_V_sample.size() << delim << "#sample size, following data: V(t1); V(t2); ..."<< endl;
		// pop_V_sample
		write2file(output_file, delim, pop_V_sample); // V_sample is a 2D matrix
	}


	// dump neuron population parameters
	output_file << indicator << " neuron population parameters" << delim << pop_ind << delim << "#pop index; data following: number of variables,;var_name1,value1,; var_name2,value2,;..." << endl;

	// count number of variables
	stringstream dump_count;
	string dump_str = dump_para(delim);
	dump_count << dump_str;
	string str_temp;
	int var_number = 0;
	while(getline(dump_count,str_temp)){++var_number;}
	output_file << var_number << delim << "#number of parameters" << endl;
	output_file << dump_str;
}






// Use function templates when you want to perform the same action on types that can be different.
// Use function overloading when you want to apply different operations depending on the type.
// In this case, just save yourself the trouble and use overloading.
void Neurons::write2file(ofstream& output_file, char delim, vector< vector<int> >& v){
	if (!v.empty()){
		for (unsigned int i = 0; i < v.size(); ++i){
			//for (double f : v[i]){ output_file << f << delim; } // range-based "for" in C++11
			for (unsigned int j = 0; j < v[i].size(); ++j){
				output_file << v[i][j] << delim;
			}
			output_file << endl;
		}
	}
	else {output_file << " " << endl;}
}



void Neurons::write2file(ofstream& output_file, char delim, vector< vector<double> >& v){
	if (!v.empty()){
		for (unsigned int i = 0; i < v.size(); ++i){
			//for (double f : v[i]){ output_file << f << delim; } // range-based "for" in C++11
			for (unsigned int j = 0; j < v[i].size(); ++j){
				output_file << v[i][j] << delim;
			}
			output_file << endl;
		}
	}
	else {output_file << " " << endl;}
}


void Neurons::write2file(ofstream& output_file, char delim, vector<int>& v){
	if (!v.empty()){
		//for (int f : v){ output_file << f << delim; } // range-based "for" in C++11
		for (unsigned int i = 0; i < v.size(); ++i){
			output_file << v[i] << delim;
		}
		output_file << endl;
	}
	else {output_file << " " << endl;}
}




