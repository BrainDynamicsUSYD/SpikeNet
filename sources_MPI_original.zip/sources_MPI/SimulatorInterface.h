#ifndef SIMULATORINTERFACE_H
#define SIMULATORINTERFACE_H


#include <iostream> // ofstream: Stream class to write on files, ifstream : Stream class to read from files, istringstream is for input, ostringstream for output
#include <fstream> // fstream : Stream class to both read and write from / to files
#include <sstream>  // stringstream is input and output
#include <string> // "" for string, '' for char


#include <vector>

#include "NeuronNetwork.h"

using namespace std;

class SimulatorInterface{
public:
	SimulatorInterface();
	NeuronNetwork network; // use container?
	
	// Import Network Setup Data
	string in_filename; // path+name
	bool import(string in_filename);
	void simulate();
	
	// output data
	string output_filename;
	ofstream output_file;
	string output_suffix; // output filename extension
	char delim; // delim used to delimit the entries in the same line in files, note that the last entry of each line also has a delim
	char indicator; // indicator of data-info line, always the first char in a line, followed by infomation about following data, say, name of the data variable, population index, etc
	void output_results();

};

#endif
