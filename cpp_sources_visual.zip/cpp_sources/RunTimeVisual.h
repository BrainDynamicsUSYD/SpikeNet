#ifndef RUNTIMEVISUAL_H
#define RUNTIMEVISUAL_H
#include <vector>

using namespace std;

void run_time_visual(const char* win_name, vector<double> &v, const int row, const int col, const double min, const double max);

#endif
