#include "NeuronNetwork.h"
#include "SimulatorInterface.h"

#include <chrono> // #include <boost/chrono.hpp>

using namespace std;

SimulatorInterface::SimulatorInterface(){
	// define default output data file format
	output_suffix = ".ygout"; // filename extension
	delim = ',';
	indicator = '>';
	commentor = '#';
}

bool SimulatorInterface::import(string in_filename_input){
	// read main input file
	in_filename = in_filename_input;
	inputfile.open(in_filename, ifstream::in);
	if (inputfile){
		cout << "------------------------------------------------------------" << endl;
		cout << "Importing " << in_filename << "..." << endl;
	}
	else {
		cout << "Error: cannot open file" << in_filename << endl;
		return 0;
	}
	
	// claim variables to be assigned
	int Num_pop;
	double dt;
	int step_tot;
	vector<int> N_array;
	// temporary data storage
	vector<string> pop_para; // parameters of neuron popluation
	string syn_para; // parameters of synapses
	vector< vector<double> > ext_spike_settings; // (int pop_ind, int type_ext, double K_ext, int Num_ext, double rate_ext)
	vector< vector<double> > rate_ext_t; // vector<duoble> rate_ext(t)
	vector< vector<double> > ext_current_settings; // (int pop_ind, double mean, double std)
	vector<double> init_condition_settings; // (double p_fire)
	vector<int> neuron_sampling_pop_ind; //
	vector< vector<int> > neuron_sampling_ind; //
	vector< vector<bool> > neuron_sampling_type; //
	vector<double> runaway_killer_setting; // [runaway_steps, runaway_mean_num_ref]
	vector< vector<bool> > pop_sampling_index; // the length of time vector
	vector<int> pop_sampling_pop_ind;
	string syn_filename; // name of file that defines synaptic connection

	// read data
	string line_str, entry_str; // temporary container for the entire while loop
	size_t found;
	while (getline(inputfile, line_str)){
		istringstream line_ss(line_str); // local variable: lifetime is only a signle loop (scope is within "{}")! reusing it by ".str()" may cause fatal error because the internal error flag remains the same. Everytime using "while(getline(...)){}" will change internal error flag!
		if (line_str.empty()){continue;}
		else if (line_str.front() == commentor){continue;}
		else if (line_str.front() == indicator){// read data-info line

			// read number of neurons in each population
			found = line_str.find("INIT001");
			if (found != string::npos){// if found match
				cout << "\t Reading number of neurons in each population..." << endl;
				read_next_line_as_vector(N_array);

				// Infer number of populations
				Num_pop = N_array.size();
				pop_para.resize(Num_pop); // ??????
				continue; // move to next line
			}




			// read time step length and total steps
			found = line_str.find("INIT002");
			if (found != string::npos){// if found match
				cout << "\t Reading time step length and total steps..." << endl;
				getline(inputfile, line_str);istringstream line_ss(line_str);// Read next line

				dt = read_next_entry<double>(line_ss);
				step_tot = read_next_entry<int>(line_ss);
				continue; // move to next line
			}



			// Random initial distributions for membrane potentials 
			found = line_str.find("INIT003");
			if (found != string::npos){// if found match
				cout << "\t Reading random initial distributions for membrane potentials..." << endl;
				read_next_line_as_vector(init_condition_settings); // p_fire
				continue; // move to next line
			}


			// read external current setting
			found = line_str.find("INIT004");
			if (found != string::npos){// if found match
				cout << "\t Reading external current settings..." << endl;
				ext_current_settings.resize(ext_current_settings.size()+1);
				// [pop_ind, mean, std];
				read_next_line_as_vector(ext_current_settings.back()); // vec[vec.size()-1] ?
				continue; // move to next line
			}



			// read external spike setting
			found = line_str.find("INIT005");
			if (found != string::npos){// if found match
				cout << "\t Reading external spike settings..." << endl;
				// [pop_ind,type_ext,K_ext,Num_ext]
				ext_spike_settings.resize(ext_spike_settings.size()+1);
				read_next_line_as_vector(ext_spike_settings.back());
				// [rate_ext_t]
				rate_ext_t.resize(rate_ext_t.size()+1);
				read_next_line_as_vector(rate_ext_t.back());
				continue; // move to next line
			}



			// read neuron population parameter setting
			found = line_str.find("PARA001");
			if (found != string::npos){// if found match
				cout << "\t Reading non-default neuron population parameters..." << endl;
				getline(inputfile, line_str);istringstream line_ss(line_str);// Read next line
				// pop_ind and number of parameters
				int pop_ind = read_next_entry<int>(line_ss); 
				int num_para = read_next_entry<int>(line_ss);
				// store parameter settings
				for (int c = 0; c < num_para; ++c){
					getline(inputfile, line_str); // read next line
					pop_para[pop_ind] += line_str; // append (+=)
				}
				continue; // move to next line
			}



			// read synapse parameter setting
			found = line_str.find("PARA002");
			if (found != string::npos){// if found match
				cout << "\t Reading non-default synapse parameters..." << endl;
				getline(inputfile, line_str);istringstream line_ss(line_str);// Read next line
				// number of parameters
				int num_para = read_next_entry<int>(line_ss);
				// store parameter settings
				for (int c = 0; c < num_para; ++c){
					getline(inputfile, line_str); // read next line
					syn_para += line_str; // append (+=)
				}
				continue; // move to next line
			}



			// read runaway killer setting
			found = line_str.find("KILL001");
			if (found != string::npos){
				cout << "\t Reading runaway killer setting..." << endl;
				// double steps, mean_num_ref;
				read_next_line_as_vector(runaway_killer_setting);
				continue;
			}



			// read neuron data sampling setting
			found = line_str.find("SAMP001");
			if (found != string::npos){// if found match
				cout << "\t Reading neuron data sampling settings..." << endl;
				getline(inputfile, line_str);istringstream line_ss(line_str);// Read next line
				// int pop_ind;
				neuron_sampling_pop_ind.push_back(read_next_entry<int>(line_ss));
				// sample_type
				neuron_sampling_type.resize(neuron_sampling_type.size()+1);
				read_next_line_as_vector(neuron_sampling_type.back());
				// sample_ind
				neuron_sampling_ind.resize(neuron_sampling_ind.size()+1);
				read_next_line_as_vector(neuron_sampling_ind.back());
				continue; // move to next line
			}
			

			// read population sampling setting
			found = line_str.find("SAMP002");
			if (found != string::npos){
				cout << "\t Reading population data sampling setting..." << endl;
				pop_sampling_index.resize(pop_sampling_index.size()+1);
				getline(inputfile, line_str);istringstream line_ss(line_str);// Read next line
				// int pop_ind;
				pop_sampling_pop_ind.push_back(read_next_entry<int>(line_ss));
				read_next_line_as_vector(pop_sampling_index.back());
				continue;
			}


			// read non-default synapse definition file name
			found = line_str.find("SYNF001");
			if (found != string::npos){
				cout << "\t Reading non-default synapse definition file name..." << endl;
				getline(inputfile, syn_filename); // Read next line 
				continue;
			}

			else{
				cout << "Unrecognized command sequence: " << line_str << endl;
			}

		} //read data-info line	

	} // while
	inputfile.close();
	inputfile.clear();

	// read synapse definition input file
	if (syn_filename.empty()){ // default file name
		syn_filename = in_filename;
		syn_filename.append("_syn"); // .ygin_syn
	}

	inputfile.open(syn_filename, ifstream::in); // close, clear and then open: reusing is a bad practice?
	if (inputfile){}
	else {
		cout << "Error: cannot open file" << in_filename << endl;
		return 0;
	}
	
	// temporary data storage
	vector< vector<int> > I_temp, J_temp; //for chemical synapses
	vector< vector<double> > K_temp, D_temp; //for chemical synapses
	vector< vector<int> > IJKD_chem_info; // {Type(0:AMPA/1:GABAa/2:NMDA),Pre_pop_ind(0/1/...),Post_pop_ind(0/1/...)}
	
	// read data
	while (getline(inputfile, line_str)){
		istringstream line_ss(line_str);
		if (line_str.empty()){continue;}
		else if (line_str.front() == commentor){continue;}
		else if (line_str.front() == indicator){// read data-info line
			
			// read connection data: [I;J;K;D] (chemical)
			found = line_str.find("INIT006");
			if (found != string::npos){// if found match
				cout << "\t Reading chemical connection..." << endl;
				// [type, pre_pop_ind, post_pop_ind]
				IJKD_chem_info.resize(IJKD_chem_info.size()+1);
				read_next_line_as_vector(IJKD_chem_info.back());
				// I_temp
				I_temp.resize(I_temp.size()+1);
				read_next_line_as_vector(I_temp.back());
				// J_temp
				J_temp.resize(J_temp.size()+1);
				read_next_line_as_vector(J_temp.back());
				// K_temp
				K_temp.resize(K_temp.size()+1);
				read_next_line_as_vector(K_temp.back());
				// D_temp
				D_temp.resize(D_temp.size()+1);		
				read_next_line_as_vector(D_temp.back());

				continue; // move to next line
			}
		}//read data-info line	

		
	} // while

	inputfile.close();
	inputfile.clear();







	// build NeuronNetwork based on data imported
	network = NeuronNetwork(N_array, dt, step_tot);
	cout << "\t Network created." << endl;
	cout << "\t Initialising neuron populations...";
	for (unsigned int ind = 0; ind < N_array.size(); ++ind){
		network.NeuronPopArray.push_back(Neurons(ind, N_array[ind], network.dt, network.step_tot));
		network.NeuronPopArray.back().set_para(pop_para[ind], delim);
		cout << ind+1 << "...";
	}
	cout << "done." << endl;

	// chemical connections
	if (I_temp.size() != 0){
		cout << "\t Initialising chemical synapses... ";
		for (unsigned int ind = 0; ind < I_temp.size(); ++ind){
			int type = IJKD_chem_info[ind][0];
			int i_pre = IJKD_chem_info[ind][1];
			int j_post = IJKD_chem_info[ind][2];
			network.ChemicalSynapsesArray.push_back(ChemicalSynapses(network.dt, network.step_tot));
			network.ChemicalSynapsesArray.back().init(type, i_pre, j_post, network.N_array[i_pre], network.N_array[j_post], I_temp[ind], J_temp[ind], K_temp[ind], D_temp[ind]);
			network.ChemicalSynapsesArray.back().set_para(syn_para, delim);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// external spike setting (int pop_ind, int type_ext, double K_ext, int Num_ext)
	// vector<double> rate_ext_t
	if (ext_spike_settings.size() != 0){
		cout << "\t External spike settings...";
		for (unsigned int ind = 0; ind < ext_spike_settings.size(); ++ind){
			int j_post = int(ext_spike_settings[ind][0]);
			int type_ext = int(ext_spike_settings[ind][1]);
			double K_ext = ext_spike_settings[ind][2];
			int Num_ext = int(ext_spike_settings[ind][3]);
			network.ChemicalSynapsesArray.push_back(ChemicalSynapses(network.dt, network.step_tot));
			network.ChemicalSynapsesArray.back().init(type_ext, j_post, network.N_array[j_post], K_ext, Num_ext, rate_ext_t[ind]);
			network.ChemicalSynapsesArray.back().set_para(syn_para, delim);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// external current setting (int pop_ind, double mean, double std)
	if (ext_current_settings.size() != 0){
		cout << "\t External current settings...";
		for (unsigned int ind = 0; ind < ext_current_settings.size(); ++ind){
			int pop_ind = int(ext_current_settings[ind][0]);
			double mean = ext_current_settings[ind][1];
			double std = ext_current_settings[ind][2];
			network.NeuronPopArray[pop_ind].set_gaussian_I_ext(mean, std);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// random initial condition settings (double p_fire)
	if (init_condition_settings.size() != 0){
		cout << "\t Random initial condition settings...";
		for (unsigned int pop_ind = 0; pop_ind < init_condition_settings.size(); ++pop_ind){
			double p_fire = init_condition_settings[pop_ind];
			network.NeuronPopArray[pop_ind].random_V(p_fire);
			cout << pop_ind+1 << "...";
		}
		cout << "done." << endl;
	}
	
	// neuron data sampling settings(int pop_ind, vector<int> sample_ind)
	if (neuron_sampling_pop_ind.size() != 0){
		cout << "\t Neuron data sampling settings...";
		for (unsigned int ind = 0; ind < neuron_sampling_pop_ind.size(); ++ind){
			int pop_ind = neuron_sampling_pop_ind[ind];
			network.NeuronPopArray[pop_ind].add_neuron_sampling(neuron_sampling_ind[ind], neuron_sampling_type[ind]);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}	
	
	// population data (membrane potential) sampling
	if (pop_sampling_pop_ind.size() != 0){
		cout << "\t Population data sampling settings...";
		for (unsigned int ind = 0; ind < pop_sampling_pop_ind.size(); ++ind){
			int pop_ind = pop_sampling_pop_ind[ind];
			network.NeuronPopArray[pop_ind].add_pop_sampling(pop_sampling_index[ind]);
			cout << ind+1 << "...";
		}
		cout << "done." << endl;
	}

	// initialise runaway-killer
	if (runaway_killer_setting.size() != 0){
		for (int ind = 0; ind < network.Num_pop; ++ind){
			network.NeuronPopArray[ind].init_runaway_killer(int(runaway_killer_setting[0]), runaway_killer_setting[1]);
		}
		cout << "\t Runaway killer licensed." << endl;
		cout << "\t \t No women, no kids." << endl;
	}


	cout << "Importing done." << endl;
	return 1;
}

void SimulatorInterface::simulate(){
	// simulate
	for (int i = 0; i < network.step_tot; ++i){
		network.update(i);
	}
	cout << "Simulation done." << endl;
}

void SimulatorInterface::output_results(){


	// creat output file
	out_filename = gen_out_filename();
	output_file.open(out_filename);
	
	
	// write data
	cout << "Outputting results into file..." << endl;
	
	// KILL002 # step at which runaway activity is killed
	output_file << indicator << " KILL002" << endl;
	output_file << network.step_killed << delim << endl;

	// dump population data
	for (int i = 0; i < network.Num_pop; i++){
		network.NeuronPopArray[i].output_results(output_file, delim, indicator);
	}

	// dump synapse data
	for (unsigned int i = 0; i < network.ChemicalSynapsesArray.size(); i++){
		network.ChemicalSynapsesArray[i].output_results(output_file, delim, indicator);
	}

	// attach input file (.ygin) to the output file for data completeness
 	ifstream in_file_attach( in_filename ) ;
        output_file << in_file_attach.rdbuf() ;


	cout << "Outputting done." << endl << "------------------------------------------------------------" << endl;
	// Write data file name to stdout and use "grep ygout" to extract it!
	cout << "Data file name is: " << endl;
	cout << "	" << out_filename << endl;
}



string SimulatorInterface::gen_out_filename(){
	// creat output file name using some pre-defined format
	ostringstream convert_temp;   // stream used for the conversion
	// Make use of the input file path and name
	string in_filename_trim;
	istringstream in_filename_ss(in_filename);
	getline(in_filename_ss, in_filename_trim, '.');
	// Using time since epoch to stamp the output file
	chrono::high_resolution_clock::duration tse = chrono::high_resolution_clock::now().time_since_epoch();
	chrono::milliseconds tse_ms = chrono::duration_cast<chrono::milliseconds>(tse);
	unsigned long long time_stamp = tse_ms.count(); // ms from epoch, better than "time_t time_stamp = time(0);"
	// Combine all the parts of the output file path and name
	convert_temp << in_filename_trim << "_" << time_stamp << output_suffix; // insert the textual representation of 'Number' in the characters in the stream
	return convert_temp.str(); // set 'Result' to the contents of the stream
}




template < typename Type > Type SimulatorInterface::read_next_entry(istringstream &line_ss){
	string entry_str;
	Type entry;
	getline(line_ss, entry_str, delim);
	if (entry_str.empty()){
		cout << "ERROR: SimulatorInterface::read_next_entry: empty content!" << endl;
	}
	stringstream(entry_str) >> entry;
	return entry;
}

template < typename Type, typename A > void SimulatorInterface::read_next_line_as_vector(vector<Type, A> &vec){
	
	string line_str, entry_str;
	Type entry;
	getline(inputfile, line_str); istringstream line_ss(line_str); // read next line
	if (line_str.empty()){
		cout << "ERROR: SimulatorInterface::read_next_line_as_vector: empty string!" << endl;
	}
	while (getline(line_ss, entry_str, delim)){
		stringstream(entry_str) >> entry;
		vec.push_back(entry);
	}

}

void SimulatorInterface::write2file(vector<int>& v){
	if (!v.empty()){
		//for (int f : v){ output_file << f << delim; } // range-based "for" in C++11
		for (unsigned int i = 0; i < v.size(); ++i){
			output_file << v[i] << delim;
		}
		output_file << endl;
	}
	else {output_file << " " << endl;}
}




