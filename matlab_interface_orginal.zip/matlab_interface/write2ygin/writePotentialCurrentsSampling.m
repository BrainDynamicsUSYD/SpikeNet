function writePotentialCurrentsSampling(FID, pop_ind, sample_ind)
% for C/C++ index convetion
pop_ind = pop_ind-1;
sample_ind = sample_ind-1;
% write
fprintf(FID, '%s\n', '> membrane potential and currents sampling // pop_ind;sample_ind');
fprintf(FID, '%d,\n', pop_ind);
fprintf(FID, '%d,', sample_ind); fprintf(FID,'\n');
fprintf(FID, '\n');
