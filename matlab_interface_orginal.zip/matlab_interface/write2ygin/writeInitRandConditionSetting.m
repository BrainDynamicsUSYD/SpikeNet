function writeInitRandConditionSetting(FID, pop_ind, p_fire)
pop_ind = pop_ind - 1;
fprintf(FID, '%s\n', '> random initial condition // (pop_ind, p_fire)');
fprintf(FID, '%.6f,', [pop_ind, p_fire]);fprintf(FID,'\n\n');
end

