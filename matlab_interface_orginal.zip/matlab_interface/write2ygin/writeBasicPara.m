function writeBasicPara(FID, Num_pop, dt, step_tot, N)
fprintf(FID, '%s\n', '> number of populations (Num_pop)');
fprintf(FID, '%d,\n\n', Num_pop);
fprintf(FID, '%s\n', '> time step (dt) //(ms)');
fprintf(FID, '%.9f,\n\n', dt);
fprintf(FID, '%s\n', '> total steps (step_tot)');
fprintf(FID, '%d,\n\n', step_tot);
fprintf(FID, '%s\n', '> number of neurons');
fprintf(FID, '%d,', N); fprintf(FID,'\n\n');
end

