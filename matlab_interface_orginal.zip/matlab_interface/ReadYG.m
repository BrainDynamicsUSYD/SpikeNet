function [ OutData ] = ReadYG( files )
% files are cell of array of char array (strings) defining the path of input files
% If given no argument, it searches for matches under CURRENT directory
disp('ReadYG...');
tic;


% Prepare filenames
if nargin == 0
    % If given no argument, search for matches under CURRENT directory
    dir_strut = dir('*.ygout');
    num_files = length(dir_strut);
    files = cell(1,num_files);
    for id_out = 1:num_files
        files{id_out} = dir_strut(id_out).name;
    end
    % all the corresponding input files under CURRENT directory
    in_all_dir = dir('*.ygin');
    in_all = cell(1,1);
    for id_in = 1:length(in_all_dir)
        in_all{id_in} = in_all_dir(id_in).name;
    end
    
else
    % all the corresponding input files
    files_dir = fileparts(files{1}); % assuming all the input files are under the same directory
    if ~isempty(files_dir) % if not under current directory
        in_all_dir = dir(strcat(files_dir,'/*.ygin'));
        in_all = cell(1,1);
        for id_in = 1:length(in_all_dir)
            in_all{id_in} = strcat(files_dir,'/',in_all_dir(id_in).name);
        end
    else % if under current directory
        in_all_dir = dir('*.ygin');
        in_all = cell(1,1);
        for id_in = 1:length(in_all_dir)
            in_all{id_in} = in_all_dir(id_in).name;
        end
    end
end

OutData = cell(1,length(files));

if ~isempty(files)
% Read ygout file(s) specified by "name" and write data to "OutData"
for id_out = 1:length(files)
    % OutData{id_out}.file = files{id_out};
    [file_dir, file_name, ~] = fileparts(files{id_out});
    if ~isempty(file_dir)
        OutData{id_out}.stamp = strcat(file_dir,'/', file_name);
    else
        OutData{id_out}.stamp = file_name;
    end
    fprintf('Current ReadYG file is: %s\n', files{id_out});
    FID = fopen(files{id_out},'r');
    % prepare containers
    OutData{id_out}.step_killed = [];
    OutData{id_out}.Num_pop = [];
    OutData{id_out}.dt = [];
    OutData{id_out}.step_tot = [];
    OutData{id_out}.N = [];
    OutData{id_out}.spike_hist = cell(0,0);
    OutData{id_out}.num_spikes = cell(0,0);
    OutData{id_out}.num_ref = cell(0,0);
    OutData{id_out}.VI_sample = [];
    OutData{id_out}.ExplVar = [];
    OutData{id_out}.RespVar = [];
    OutData{id_out}.PopPara = cell(0,0);
    OutData{id_out}.SynPara = cell(0,0);
    OutData{id_out}.pop_V_sample = cell(0,0);
    
    while ~feof(FID)
        tline = fgetl(FID);
        % search for data-info line
        if isempty(tline)
            continue;
        elseif strcmp(tline(1), '>')
            if strfind(tline,'step_killed');
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                OutData{id_out}.step_killed = scan_temp{2}; 
            elseif strfind(tline,'spike_hist_tot')
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                pop_ind = scan_temp{2}+1; % be careful here!
                tline = fgetl(FID);
                scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                OutData{id_out}.spike_hist{pop_ind,1} = transpose(scan_temp{1} + 1); % Be careful here! C/C++ index convection!
            elseif strfind(tline,'num_spikes_pop')
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                pop_ind = scan_temp{2}+1; % be careful here!
                tline = fgetl(FID);
                scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                OutData{id_out}.num_spikes{pop_ind,1} = transpose(scan_temp{1});
            elseif strfind(tline,'num_ref_pop')
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                pop_ind = scan_temp{2}+1; % be careful here!
                tline = fgetl(FID);
                scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                OutData{id_out}.num_ref{pop_ind,1} = transpose(scan_temp{1});
            elseif strfind(tline,'VI_sample')
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                pop_ind = scan_temp{2}+1; % be careful here!
                % read sample size
                tline = fgetl(FID);
                scan_temp = textscan(tline, '%f %s', 'Delimiter', ',');
                sample_size = scan_temp{1}(1);
                % read neuron index vector
                tline = fgetl(FID); % read next line
                scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                VI_sample_ind = scan_temp{1}+1; % Be careful here! C/C++ index convection!
                OutData{id_out}.VI_sample.ind{pop_ind,1} = double([repmat(pop_ind,length(VI_sample_ind),1), VI_sample_ind]); % two-column:pop_ind, neuron_ind
                % read V_sample matrix
                step_tot = length(OutData{id_out}.num_spikes{pop_ind});
                OutData{id_out}.VI_sample.V{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.V{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
                % read I_sample matrices
                % leak
                OutData{id_out}.VI_sample.I_leak{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.I_leak{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
                % AMPA
                OutData{id_out}.VI_sample.I_AMPA{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.I_AMPA{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
                % GABA
                OutData{id_out}.VI_sample.I_GABA{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.I_GABA{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
                % NMDA
                OutData{id_out}.VI_sample.I_NMDA{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.I_NMDA{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
                % GJ
                OutData{id_out}.VI_sample.I_GJ{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.I_GJ{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
                % ext
                OutData{id_out}.VI_sample.I_ext{pop_ind,1} = zeros(sample_size,step_tot);
                for sample_ind = 1:sample_size
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.VI_sample.I_ext{pop_ind,1}(sample_ind,:) = transpose(scan_temp{1});
                end
            elseif strfind(tline,'neuron population parameters')
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                pop_ind = scan_temp{2}+1; % be careful here!
                tline = fgetl(FID);
                scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                num_para = scan_temp{1}; % number of parameters
                for p = 1:num_para
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%s %f', 'Delimiter', ',');
                    para_name = scan_temp{1}{1};
                    para_value = scan_temp{2};
                    OutData{id_out}.PopPara{pop_ind}.(para_name) = para_value;
                end
            elseif strfind(tline,'synapse parameters')
                tline = fgetl(FID);
                scan_temp = textscan(tline, '%d %s', 'Delimiter', ',');
                num_para = scan_temp{1}; % number of parameters
                num_syn = length(OutData{id_out}.SynPara)+1;
                for p = 1:num_para
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%s %f', 'Delimiter', ',');
                    para_name = scan_temp{1}{1};
                    para_value = scan_temp{2};
                    OutData{id_out}.SynPara{num_syn}.(para_name) = para_value;
                end
            elseif strfind(tline,'pop_V_sample')
                scan_temp = textscan(tline,'%s %d %s','Delimiter',',');
                pop_ind = scan_temp{2}+1; % be careful here!
                tline = fgetl(FID); % new line
                scan_temp = textscan(tline, '%d %s', 'Delimiter', ',');
                sample_num = scan_temp{1}; % number of parameters
                for s = 1:sample_num
                    tline = fgetl(FID); % read next line
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    OutData{id_out}.pop_V_sample{pop_ind}(:,s) = scan_temp{1};
                end
            else
                disp('Warning: unrecognized data type!!!');
            end
        end
            
    end
    fclose(FID);
end


% Read according ygin file for each ygout file
% This is taking a time too fxxking long!!!
% No need to read through the whole .ygin file just to find several
% information!

for id_in = 1:length(in_all)
    % Find according according ygin file for each ygout file
    id_in_out = [];
    scan_temp = textscan(in_all{id_in}, '%s %s', 'Delimiter', '.');
    name_in = scan_temp{1};
    for id_out = 1:length(files) % (note that several ygout files may share a common ygin file)
        scan_temp = textscan(files{id_out}, '%s %s', 'Delimiter','_' );
        name_out = scan_temp{1};
        if strcmp(name_in, name_out)
            id_in_out(end+1) = id_out;
        end
    end
    % Read ygin file and write data to according "DataOut"
    if ~isempty(id_in_out)
        fprintf('Current ReadYG file is: %s\n', in_all{id_in});
        FID = fopen(in_all{id_in},'r');
        
        data_type = -1;
        while ~feof(FID)
            tline = fgetl(FID); % using A = textscan(FID,'%s','delimiter','\n'); can be faster!!
            % search for data-info line
            if isempty(tline)
                continue;
                
            elseif strcmp(tline(1), '>')
                if strfind(tline,'number of populations')
                    tline = fgetl(FID);
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    for id_out = id_in_out
                        OutData{id_out}.Num_pop = scan_temp{1};
                    end
                    
                elseif strfind(tline,'time step')
                    tline = fgetl(FID);
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    for id_out = id_in_out
                        OutData{id_out}.dt = scan_temp{1};
                    end
                    
                elseif strfind(tline,'total steps')
                    tline = fgetl(FID);
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    for id_out = id_in_out
                        OutData{id_out}.step_tot = scan_temp{1};
                    end
                    
                elseif strfind(tline, 'number of neurons')
                    tline = fgetl(FID);
                    scan_temp = textscan(tline, '%f', 'Delimiter', ',');
                    for id_out = id_in_out
                        OutData{id_out}.N = scan_temp{1};
                    end
                    
                elseif strfind(tline, 'explanatory variable')
                    tline = fgetl(FID);
                    scan_temp1 = textscan(tline, '%s', 'Delimiter', ',');
                    if strfind(tline,'comment') % read as string
                        tline = fgetl(FID);
                        scan_temp2 = textscan(tline, '%s', 'Delimiter', ',');
                        for id_out = id_in_out
                            %OutData{id_out}.ExplVar(end+1,1) =  scan_temp1{1};
                            eval(cell2mat(strcat('OutData{id_out}.ExplVar.', scan_temp1{1}, '= cell2mat(scan_temp2{1});')));
                        end
                    else % read as numeric
                        tline = fgetl(FID); 
                        scan_temp2 = textscan(tline, '%f', 'Delimiter', ',');
                        for id_out = id_in_out
                            %OutData{id_out}.ExplVar(end+1,1) =  scan_temp1{1};
                            eval(cell2mat(strcat('OutData{id_out}.ExplVar.', scan_temp1{1}, '= scan_temp2{1};')));
                        end
                    end
                    
                elseif strfind(tline, 'response variable')
                    tline = fgetl(FID);
                    scan_temp = textscan(tline, '%s', 'Delimiter', ',');
                    for id_out = id_in_out
                        OutData{id_out}.RespVar(end+1,1) = scan_temp{1};
                    end
                end
            end
            
        end
        fclose(FID);

    end
    
end


% Re-formatting data
fprintf('\t Re-formatting data...\n');
Result_num = length(OutData);
for r_num = 1:Result_num
    
    % Re-format VI_sample into coloum matrix
    OutData{r_num} = ReformatVI_sample(OutData{r_num});

    % Reformat spike history data
    OutData{r_num} = ReformatSpikeHistory(OutData{r_num});
 
    % Discard transient data
    OutData{r_num} = DiscardTransientData(OutData{r_num});
    
    % Reduce solution
    OutData{r_num} = ReduceSolution(OutData{r_num});
end

end % if ~isempty(name)

toc;

end


function Data = ReformatVI_sample(Data)
    % Re-format VI_sample into coloum matrix
    if any( strcmp(fieldnames(Data), 'VI_sample') ) && ~isempty(Data.VI_sample) 
        fname_cell = fieldnames(Data.VI_sample);
        for f = 1:length(fname_cell)
            fn = fname_cell{f};
            Data.VI_sample.(fn) = cell2mat(Data.VI_sample.(fn));
        end
    end
end

function Data = ReformatSpikeHistory(Data)
    % Re-format the raw (compressed) spike history data into natural structure
    % (logical sparse matrix)
    % Dump relevant fields
    Num_pop = Data.Num_pop;
    step_tot = Data.step_tot;
    N = Data.N;
    spike_hist = Data.spike_hist;
    num_spikes = Data.num_spikes;
    
    % Re-format the raw spike history data into natural structure
    spike_hist_natural = cell(Num_pop,1);
    for pop_ind = 1:Num_pop
        if nnz(num_spikes{pop_ind}) > 0
            T_ind_full = cell2mat(arrayfun(@(x, y) repmat(x, [1 y]), 1:step_tot, num_spikes{pop_ind}, 'UniformOutput', false));
            spike_hist_natural{pop_ind} = sparse(spike_hist{pop_ind}, T_ind_full, true(size(T_ind_full)), N(pop_ind), step_tot);
        else
            spike_hist_natural{pop_ind} = sparse(false(N(pop_ind), step_tot));
        end
    end
    Data.spike_hist_compressed = Data.spike_hist;
    Data.spike_hist = spike_hist_natural; % overwrite spike history data (logical sparse matrix)
end


function Data = DiscardTransientData(Data)
    % Discard trainsient data
    if any( strcmp(fieldnames(Data.ExplVar), 'discard_transient') ) && Data.ExplVar.discard_transient > 0
        discard_transient = Data.ExplVar.discard_transient;
        step_tot_dis = round(Data.step_tot*(1-discard_transient));
        for pop_ind = 1:Data.Num_pop
            Data.spike_hist{pop_ind} = Data.spike_hist{pop_ind}(:,end-step_tot_dis+1:end);
            if nnz(Data.num_spikes{pop_ind}) > 0
                Data.spike_hist_compressed{pop_ind} = Data.spike_hist_compressed{pop_ind}(sum(Data.num_spikes{pop_ind}(1:end-step_tot_dis))+1:end);
            end
            Data.num_spikes{pop_ind} = Data.num_spikes{pop_ind}(end-step_tot_dis+1:end);
            Data.num_ref{pop_ind} = Data.num_ref{pop_ind}(end-step_tot_dis+1:end);
        end
        if any( strcmp(fieldnames(Data), 'VI_sample') ) && ~isempty(Data.VI_sample) 
            fname_cell = fieldnames(Data.VI_sample);
            for f = 2:length(fname_cell) % skip first field
                fn = fname_cell{f};
                Data.VI_sample.(fn) = Data.VI_sample.(fn)(:,end-step_tot_dis+1:end);
            end
        end
        Data.step_tot = step_tot_dis;
    end
end


function Data = ReduceSolution(Data)
    % Re-format the raw spike history data into natural structure with
    % reduced resolution
    % Dump relevant fields
    Num_pop = Data.Num_pop;
    step_tot = Data.step_tot;
    N = Data.N;
    dt = Data.dt;
    spike_hist_compressed = Data.spike_hist_compressed;
    num_spikes = Data.num_spikes;
    num_ref = Data.num_ref;
    
    reduced_dt = 1; % (ms)
    reduced_step_length = round(reduced_dt/dt);
    reduced_step_tot = ceil(step_tot/reduced_step_length);
    reduced_spike_hist = cell(Num_pop,1);
    reduced_num_spikes = cell(Num_pop,1);
    reduced_num_ref = cell(Num_pop,1);
    
    for pop_ind = 1:Num_pop
        if nnz(num_spikes{pop_ind}) > 0
            reduced_num_spikes_temp = [num_spikes{pop_ind} zeros(1, reduced_step_tot*reduced_step_length-step_tot)]; % padding
            reduced_num_spikes_temp = sum(reshape(reduced_num_spikes_temp, reduced_step_length, reduced_step_tot),1);
            reduced_T_ind_full = cell2mat(arrayfun(@(x, y) repmat(x, [1 y]), 1:reduced_step_tot, reduced_num_spikes_temp, 'UniformOutput', false));
            reduced_spike_hist{pop_ind} = sparse(spike_hist_compressed{pop_ind}, reduced_T_ind_full, true(size(reduced_T_ind_full)), N(pop_ind), reduced_step_tot);
            reduced_num_spikes{pop_ind} = full(sum(reduced_spike_hist{pop_ind},1));
            reduced_num_ref{pop_ind} = num_ref{pop_ind}(round(linspace(1,step_tot,reduced_step_tot))); % down-sampling
        end
    end

    Data.reduced_dt = reduced_dt;
    Data.reduced_step_tot = reduced_step_tot;
    Data.reduced_spike_hist = reduced_spike_hist;
    Data.reduced_num_spikes = reduced_num_spikes;
    Data.reduced_num_ref = reduced_num_ref;

end

